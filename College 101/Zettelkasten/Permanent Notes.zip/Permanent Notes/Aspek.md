Date: 2025-05-07
Time: 09:16
Status: #small 
Tags:


# Aspek
Aspek adalah bagian-bagian kecil dari [[Dimensi]]. Jika dimensi adalah bagian-bagian rumah, Aspek adalah furnitur dari bagian bagian tersebut. Sebagai contoh didalam AMS (Academic Motivation Scale) Aspek dari [[Dimensi]] Motivasi Intrinsik antara lain:
- **To know** (curiosity)
- **Toward accomplishment** (feeling of achievement)
- **To experience stimulation** (fun/excitement)


# References
[[Dimensi]]