Date: 2025-04-14
Time: 10:44
Status: #medium 
Tags:


# Chepalocaudal
Sebuah pola pertumbuhan anak dimana growth dan motor control dimulai dari atas ke bawah
Chepalo = head
Caudal = tail

Ini terjadi karena otak dan sistem saraf berkembang dari atas kebawah.

di Developmental Psychology ini digunakan untuk:
- ngetrack progress motorik
- mendeteksi delay dalam pertumbuhan fisik
- membuat milestone pertumbuhan

irl ex:
bayi baru lahir cant do shit => start wobbling their head => around 2 month can start lifting it up themselves => 4-6 month can sit with support => 9-12 they start standing bruh

# References
