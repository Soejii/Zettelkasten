Date: 2025-04-29
Time: 10:21
Status: #medium 
Tags:


# Confirmatory Factor Analysis
Confrimatory Factor Analysis adalah metode statistik psikometri yang bertujuan untuk mengkonfirmasi apakah item-item yang dibuat jatuh pada [[Dimensi]] yang benar 

(ex. mengkonfirmasi item item yang ada di kuisoner tentang Academic Motivation Scale apakah sudah benar jatuh pada amotivasi, motivasi intrinsik, dan motivasi ekstrinsik)


# References
[[Dimensi]]