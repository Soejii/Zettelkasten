Date: 2024-09-13
Time: 22:37
Status:  #medium 
Tags:


# Covert
Sebuah konsep yang terjadi pada dalam diri manusia(internal) yang secara umum tidak terlihat dan tidak bisa di observasi

Perilaku Covert juga seringkali mendorong Perilaku Overt namun tentu saja untuk validitas dan realibilitasnya harus diukur menggunakan instrumen-instrumen

Contoh:
- Pikiran
- Emosi
- Proses berpikir
- Persepsi


# References
[[Statistika - 2]]
