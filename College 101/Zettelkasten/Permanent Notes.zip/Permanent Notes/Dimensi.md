Date: 2025-05-07
Time: 09:10
Status: #small
Tags:


# Dimensi
Dimensi itu adalah bagian inti dari konstruk psikologi yang digunakan, sebagai contoh:  AMS (Academic Motivation Scale) punya tiga bentuk Dimensi: Motivasi Intrinsik, Motivasi Ekstrinsik, dan Amotivasi

Bayangkan sebuah dimensi sebagai bagian bagian dari rumah i.e: kamar tidur, ruang tamu dll. Sedangkan Konstruk Psikologi adalah rumahnya (dalam contoh diatas adalah AMS)

Setiap dimensi dapat memiliki beberapa subdemensi lain yang disebut [[Aspek]]
# References
[[Aspek]]