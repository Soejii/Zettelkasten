Date: 2025-06-10
Time: 20:30
Status:
Tags: 


# Id
**Id** adalah bagian dari struktur _unconscious_ pada diri seseorang, penuh dengan dorongan instingtual, dan digerakkan oleh rasa kesenangan ([[Pleasure Principle]].) **Id** hanya peduli tentang kepuasaan pada saat itu juga, contoh:

You see cake. You’re on a diet. Your id doesn’t care—it says **“Eat it. Now.”**

**Id** berisi dorongan dasar seperti _Libido_, agresi, dan kebutuhan biologis lainnya. Walaupun begitu **Id**tetap dibutuhkan sebagai sumber energi psikologis untuk mendorong kita melakukan sesuatu.
# References
[[Sigmund Freud]]