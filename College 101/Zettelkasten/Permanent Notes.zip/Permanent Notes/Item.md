Date: 2025-05-07
Time: 09:19
Status: #small 
Tags:


# Item
item atau yang biasa disebut sebagai butir-butir soal adalah suatu pernyataan yang digunakan untuk mengukur [[Aspek]] tertentu dari sebuah [[Dimensi]] dalam [[Konstruk Psikologis]].

Kalau kita analogikan dalam bentuk rumah:
- [[Konstruk Psikologis]] = Rumah
- [[Dimensi]] = Ruangan
- [[Aspek]] = Furnitur
- **Item** = Bagian dari furnitur, seperti bantal di sofa atau laci di meja.

Contoh dari salah satu item yang digunakan dalam AMS (Academic Motivation Scale) dalam [[Dimensi]] Motivasi Intrinsik:
- [[Aspek]] : **To know (Curiosity)**
	- Saya merasakan kenikmatan dan kepuasan saat mempelajari hal baru.

# References
[[Dimensi]], [[Aspek]], [[Konstruk Psikologis]]