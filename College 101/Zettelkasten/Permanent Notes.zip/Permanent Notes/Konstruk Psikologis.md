Date: 2025-05-07
Time: 09:33
Status: #small 
Tags:


# Konstruk Psikologis
Konstruk Psikologis adalah sebuah konsep abstrak yang biasanya bersifat [[Covert]] dan digunakan untuk menjelaskan atau memahami perilaku mental manusia. Konstruk ini biasanya diukur menggunakan instrumen psikometrik seperti AMS (Academic Motivation Scale) untuk mengukur Konstruk Psikologis Academic Motivation (Motivasi Akademik).

Konstruk ini juga digunakan sebagai acuan untuk membentuk sebuah instrumen psikologis seperti skala, atau kuisoner. Dan dirumuskan berdasarkan teori-teori yang ada, serta penilitian sebelumnya.


# References
[[Covert]]