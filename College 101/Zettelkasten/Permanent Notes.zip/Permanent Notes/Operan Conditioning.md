Date: 2025-04-14
Time: 00:06
Status: #medium 
Tags: 


# Operan Conditioning
Operan conditioning adalah teori perkembangan (Developmental Psychology) yang dikembangkan oleh Skinner, Menjelaskan tentang bagaimana perilaku terbentuk karena konsekuensi. Didalam teori ini ada dua komponen penting yang menjadi dasar teori: Reinforcement (Meningkatkan kemungkinan perilaku), dan Punishment (Mengurangi kemungkinkan perilaku).

TL;DR
Perilaku diajarkan dari konsekuensi (setelah perilaku dilakukan). More reinforcement more behavior like, more punishment no more behavior

# References
