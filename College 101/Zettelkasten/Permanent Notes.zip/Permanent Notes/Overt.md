Date: 2024-09-13
Time: 22:57
Status: #medium 
Tags:


# Overt
Overt adalah kebalikkan dari Covert, dimana konsep ini terjadi secara external yang dapat dilihat dan diobservasi secara langsung

Contohnya:
- Gestur tubuh
- Berbicara
- Ekspresi facial



# References
[[Covert]]
[[Statistika - 2]]