Date: 2025-04-14
Time: 10:44
Status: #medium 
Tags:


# Proximodistal
Unlike [[Chepalocaudal]] yang dari atas ke bawah, Proximodistal memulai pola pertumbuhan  growth dan motor control anak dari tengah keluar
Proxi = near
Distal = out

# References
[[Chepalocaudal]]