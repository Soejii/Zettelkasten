Date: 2025-04-14
Time: 00:19
Status: #medium 
Tags:


# Punishment
Kebalikan dari [[Reinforcement]], Punishment bertujuan untuk mengurangi kemungkinan terjadinya perilaku, entah itu dengan menambahkan sesuatu yang unpleasant (Positive) atau menghilangkan sesuatu yang pleasant (negative).

ex:
- positive
	i got muted(adding something unpleasant) by my teammates because i flame them (to reduce flaming)
- Negative
	example above can be seen as a Negative Punishment too if i were to see it on another perspective.Muted as in (removing something pleasant) i cant communicate (something i enjoy) in order to remove bad behavior (flaming) 


# References
[[Reinforcement]]