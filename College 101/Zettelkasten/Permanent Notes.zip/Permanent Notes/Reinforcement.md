Date: 2025-04-14
Time: 00:17
Status: #medium 
Tags:


# Reinforcement
Reinforcement adalah sebuah penguatan yang diterima agar perilaku tersebut diulang kembali. Layaknya [[Punishment]], reinforcement ada dua macam yaitu Positive(menambahkan sesuatu yang _bagus_) dan Negative(menghilangkan sesuatu yang _buruk_).

ex:
- positive
	I got a praise from my g cuz my drip => more likely to wear drip shit
- Negative
	this is kinda hard to explain, so basically you want to remove something "bad" a delay, or stress. ex: i work faster in order to play dota
	work here serve as an annoying little shit that i need to clear ASAP, while dota is the one thing i wanted to do


# References
[[Punishment]]